/* Kali default settings */
/* Everything is handled through policies.json */
